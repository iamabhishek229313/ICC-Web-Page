var dashboard;
var t;
var header ;

function preload() {
    loadJSON("https://cricapi.com/api/matchCalendar?apikey=2PJlGa0yHGV3mMtsc2QRcx82gRn1", gotData);
}

function gotData(data) {
    console.log(data);
    t = data;
}

function setup() {
    noCanvas();
    dashboard = select(".dashboard");
    var x = t.data.length;
    header = createElement('h1',"MATCH CALENDER");
    header.style('color','WHITE');
    header.position(800,0);
    for (let i = 0; i < x; i++) {
        var date = createElement('h2',`Date - ${t.data[i].date}`);
        date.parent(dashboard);
        var name_of_play = createElement('h3',t.data[i].name);
        name_of_play.parent(dashboard);
        var line = createP("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        line.parent(dashboard);
    }

}