var nextNewsButton;
var preNewsButton;
var nextVideoButton;
var preVideoButton;
var the_video;
var sheet;
var mat_sheet;
var sliderManager = 0;
var videoManager = 0;
var the_data;
var t;

function preload() {
    the_data = loadJSON("news_cricket.json");
}

function matches_played(data) {
    t = data;
}


function setup() {
    nextNewsButton = createButton("NEXT");
    preNewsButton = createButton("PREVIOUS");
    nextVideoButton = createButton("NEXT VIDEO");
    preVideoButton  = createButton("PREVIOUS VIDEO");
    nextVideoButton.class('nvB');
    preVideoButton.class('pvB');
    nextNewsButton.class('nnB');
    preNewsButton.class('pnB');
    ////////
    sheet = select(".sheet_for_news");
    mat_sheet = select(".matches_data_content");
    the_video = select(".video1");
    ////////
    preNewsButton.position(210, 320);
    nextNewsButton.position(1220, 320);
    preVideoButton.position(210,1370);
    nextVideoButton.position(1220,1370);
    the_video.position(155,95);
    /////////
    var title = createElement('h4', `* ${the_data.data[sliderManager].title}`);
    title.parent(sheet);
    var pub = createElement('h6', `Published Date - ${the_data.data[sliderManager].publishedAt}`);
    pub.parent(sheet);
    var img = createImg(the_data.data[sliderManager].urlToImage, "Loading Image");
    img.size(250, 160);
    img.parent(sheet);
    var des = createElement('h5', `Description - ${the_data.data[sliderManager].description}`);
    des.parent(sheet);
    var content = createElement('h5', the_data.data[sliderManager].content);
    content.parent(sheet);
    var aut = createElement('h6', `Author - ${the_data.data[sliderManager].author}`);
    aut.parent(sheet);
    /////////
    nextNewsButton.mousePressed(nextSlide);
    preNewsButton.mousePressed(previousSlide);
    ////////
    nextVideoButton.mousePressed(nextVideo);
    preVideoButton.mousePressed(previousVideo);
    ///////
}




function nextSlide() {
    sheet.html('');
    sliderManager++;
    if (sliderManager >= 17) {
        sliderManager = 0;
    }
    var title = createElement('h4', `* ${the_data.data[sliderManager].title}`);
    title.parent(sheet);
    var pub = createElement('h6', `Published Date - ${the_data.data[sliderManager].publishedAt}`);
    pub.parent(sheet);
    var img = createImg(the_data.data[sliderManager].urlToImage, "Loading Image");
    img.size(250, 160);
    img.parent(sheet);
    var des = createElement('h5', `Description - ${the_data.data[sliderManager].description}`);
    des.parent(sheet);
    var content = createElement('h5', the_data.data[sliderManager].content);
    content.parent(sheet);
    var aut = createElement('h6', `Author - ${the_data.data[sliderManager].author}`);
    aut.parent(sheet);
}

function previousSlide() {
    sheet.html('');
    sliderManager--;
    if (sliderManager < 0) {
        sliderManager = 17;
    }
    var title = createElement('h4', `* ${the_data.data[sliderManager].title}`);
    title.parent(sheet);
    var pub = createElement('h6', `Published Date - ${the_data.data[sliderManager].publishedAt}`);
    pub.parent(sheet);
    var img = createImg(the_data.data[sliderManager].urlToImage, "Loading Image");
    img.size(250, 160);
    img.parent(sheet);
    var des = createElement('h5', `Description - ${the_data.data[sliderManager].description}`);
    des.parent(sheet);
    var content = createElement('h5', the_data.data[sliderManager].content);
    content.parent(sheet);
    var aut = createElement('h6', `Author - ${the_data.data[sliderManager].author}`);
    aut.parent(sheet);
}