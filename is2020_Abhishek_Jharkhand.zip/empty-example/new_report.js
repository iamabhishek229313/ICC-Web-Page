// var data ;
// function preload()
// {
//     data  = loadJSON("news_api.json");
// }

// function setup()
// {
//     noCanvas();
//     console.log(data);
// }
// function draw()
// {

// }