var button;
var page_head;

var input;
var sheet;
var idDetails;
var url1 = "https://cricapi.com/api/playerStats?apikey=2PJlGa0yHGV3mMtsc2QRcx82gRn1&pid=";

function setup() {
    noCanvas();
    button = select("#SEARCH");
    input = select('#input');
    sheet = select(".the_sheet");
    idDetails = select(".details_of_id");
    var on_the_top = createElement('h2', "Give Player ID here");
    on_the_top.position(8, 20);
    on_the_top.style('color', 'white');
    page_head = createElement('h1', "SEARCH FOR PLAYERS");
    page_head.parent(sheet);
    input.position(8, 90);
    button.position(8, 150);
    button.mousePressed(askAPI);
    ///////////////////////////////////
    var head = createElement('h1', "_______Some Players ID______");
    var line = createP("-----------------------------------------------");
    var id1 = createElement('h3', "Sachin Tendulkar - 35320");
    var id2 = createElement('h3', "Sachin Rana - 33757");
    var id3 = createElement('h3', "Thilina Masmulla - 49640");
    var id4 = createElement('h3', "Madawa Warnapura - 359200");
    var id5 = createElement('h3', "Sachin Shinde - 424221");
    var id6 = createElement('h3', "Sachin Baby - 432783");
    var id7 = createElement('h3', "Sachin Peiris - 507904");
    var id8 = createElement('h3', "Sachin Mylavarapu - 646869");
    var id9 = createElement('h3', "Sachin Dilshani de Silva - 684479");
    var id10 = createElement('h3', "Sachin Sewwandi - 684611");
    var id11 = createElement('h3', "Sachin Jayawardena - 729669");
    var id12 = createElement('h3', "Sachin Jha - 913833");
    var id13 = createElement('h3', "Sachin Nisansala - 924289");
    var id14 = createElement('h3', "Sachin Jayawardene - 945061");
    var id15 = createElement('h3', "Sachin Hewawasam - 958651");
    var id16 = createElement('h3', "Sachin Peiris - 958655");
    var id17 = createElement('h3', "Sachin Perera - 1056223");
    var id18 = createElement('h3', "Abhishek Perera - 1056371");
    var id19 = createElement('h3', "Sachin Gankal - 1057392");

    head.parent(idDetails);
    line.parent(idDetails);
    id1.parent(idDetails);
    id2.parent(idDetails);
    id3.parent(idDetails);
    id4.parent(idDetails);
    id5.parent(idDetails);
    id6.parent(idDetails);
    id7.parent(idDetails);
    id8.parent(idDetails);
    id9.parent(idDetails);
    id10.parent(idDetails);
    id11.parent(idDetails);
    id12.parent(idDetails);
    id13.parent(idDetails);
    id14.parent(idDetails);
    id15.parent(idDetails);
    id16.parent(idDetails);
    id17.parent(idDetails);
    id18.parent(idDetails);
    id19.parent(idDetails);
}

function askAPI() {
    sheet.html('');
    loadJSON(url1 + input.value(), gotData);
}

function gotData(t) {
    console.log(t);
    var image = createImg(t.imageURL);
    var name = createElement('h1', t.fullName);
    var born = createElement('h3', `Birth Date & Place - ${t.born}`);
    var country = createElement('h3', `Country - ${t.country}`);
    var current_age = createElement('h3', `Current Age - ${t.currentAge}`);
    var role = createElement('h2', `Role - ${t.playingRole}`);
    var profile = createElement("h3", t.profile);
    var l = createP("-----------------------------------------------------------------------------------------------------------------------------------------------------------------");
    var statsbat = createElement('h1', "STATISTICS : BATTING");
    var l2 = createP("-----------------------------------------------------------------------------------------------------------------------------------------------------------------");
    image.parent(sheet);
    name.parent(sheet);
    born.parent(sheet);
    country.parent(sheet);
    current_age.parent(sheet);
    role.parent(sheet);
    profile.parent(sheet);
    l.parent(sheet);
    statsbat.parent(sheet);
    l2.parent(sheet);

    var ODIs = createElement('h2', "ODIs");
    var l3 = createP("------------------------");
    ODIs.parent(sheet);
    l3.parent(sheet);

    var fourODI = createElement('h2', `4's - ${t.data.batting.ODIs['4s']}`);
    var sixODI = createElement('h2', `6's - ${t.data.batting.ODIs['6s']}`);
    var runsODI = createElement('h2', `Runs - ${t.data.batting.ODIs.Runs}`);
    var HSODI = createElement('h2', `HS - ${t.data.batting.ODIs.HS}`);
    var SRODI = createElement('h2', `SR - ${t.data.batting.ODIs.SR}`);
    var matODI = createElement('h2', `Matches - ${t.data.batting.ODIs.Mat}`);
    var aveODI = createElement('h2', `Average - ${t.data.batting.ODIs.Ave}`);
    var fiftyODI = createElement('h2', `50's - ${t.data.batting.ODIs['50']}`);
    var hundredODI = createElement('h2', `100's - ${t.data.batting.ODIs['100']}`);
    matODI.parent(sheet);
    runsODI.parent(sheet);
    fiftyODI.parent(sheet);
    hundredODI.parent(sheet);
    aveODI.parent(sheet);
    HSODI.parent(sheet);
    fourODI.parent(sheet);
    sixODI.parent(sheet);
    SRODI.parent(sheet);

    var T20Is = createElement('h2', "T20Is");
    var l4 = createP("------------------------");
    T20Is.parent(sheet);
    l4.parent(sheet);

    var fourt20 = createElement('h2', `4's - ${t.data.batting.T20Is['4s']}`);
    var sixt20 = createElement('h2', `6's - ${t.data.batting.T20Is['6s']}`);
    var runst20 = createElement('h2', `Runs - ${t.data.batting.T20Is.Runs}`);
    var HSt20 = createElement('h2', `HS - ${t.data.batting.T20Is.HS}`);
    var SRt20 = createElement('h2', `SR - ${t.data.batting.T20Is.SR}`);
    var matt20 = createElement('h2', `Matches - ${t.data.batting.T20Is.Mat}`);
    var avet20 = createElement('h2', `Average - ${t.data.batting.T20Is.Ave}`);
    var fiftyt20 = createElement('h2', `50's - ${t.data.batting.T20Is['50']}`);
    var hundredt20 = createElement('h2', `100's - ${t.data.batting.T20Is['100']}`);
    matt20.parent(sheet);
    runst20.parent(sheet);
    fiftyt20.parent(sheet);
    hundredt20.parent(sheet);
    avet20.parent(sheet);
    HSt20.parent(sheet);
    fourt20.parent(sheet);
    sixt20.parent(sheet);
    SRt20.parent(sheet);

    var test = createElement('h2', "TESTS");
    var l5 = createP("------------------------");
    test.parent(sheet);
    l5.parent(sheet);

    var fourTEST = createElement('h2', `4's - ${t.data.batting.tests['4s']}`);
    var sixTEST = createElement('h2', `6's - ${t.data.batting.tests['6s']}`);
    var runsTEST = createElement('h2', `Runs - ${t.data.batting.tests.Runs}`);
    var HSTEST = createElement('h2', `HS - ${t.data.batting.tests.HS}`);
    var SRTEST = createElement('h2', `SR - ${t.data.batting.tests.SR}`);
    var matTEST = createElement('h2', `Matches - ${t.data.batting.tests.Mat}`);
    var aveTEST = createElement('h2', `Average - ${t.data.batting.tests.Ave}`);
    var fiftyTEST = createElement('h2', `50's - ${t.data.batting.tests['50']}`);
    var hundredTEST = createElement('h2', `100's - ${t.data.batting.tests['100']}`);
    matTEST.parent(sheet);
    runsTEST.parent(sheet);
    fiftyTEST.parent(sheet);
    hundredTEST.parent(sheet);
    aveTEST.parent(sheet);
    HSTEST.parent(sheet);
    fourTEST.parent(sheet);
    sixTEST.parent(sheet);
    SRTEST.parent(sheet);


    var div1 = createP("-----------------------------------------------------------------------------------------------------------------------------------------------------------------");
    var statsbow = createElement('h1', "STATISTICS : BOWLING");
    var div2 = createP("-----------------------------------------------------------------------------------------------------------------------------------------------------------------");
    div1.parent(sheet);
    statsbow.parent(sheet);
    div2.parent(sheet);

    var ODIs = createElement('h2', "ODIs");
    var l6 = createP("------------------------");
    ODIs.parent(sheet);
    l6.parent(sheet);

    var odi_sr = createElement('h2', `SR - ${t.data.bowling.ODIs.SR}`);
    var odi_econ = createElement('h2', `Economy - ${t.data.bowling.ODIs.Econ}`);
    var odi_balls = createElement('h2', `Balls - ${t.data.bowling.ODIs.Balls}`);
    var odi_Ave = createElement('h2', `Average - ${t.data.bowling.ODIs.Ave}`);
    var odi_wkts = createElement('h2', `Wickets - ${t.data.bowling.ODIs.Wkts}`);
    var odi_mat = createElement('h2', `Matches - ${t.data.bowling.ODIs.Mat}`);
    var odi_10w = createElement('h2', `10W - ${t.data.bowling.ODIs['10w']}`);
    var odi_4w = createElement('h2', `4W - ${t.data.bowling.ODIs['4w']}`);
    var odi_5w = createElement('h2', `5W - ${t.data.bowling.ODIs['5w']}`);
    var odi_BBI = createElement('h2', `BBI - ${t.data.bowling.ODIs.BBI}`);
    var odi_BBM = createElement('h2', `BBM - ${t.data.bowling.ODIs.BBM}`);

    odi_mat.parent(sheet);
    odi_wkts.parent(sheet);
    odi_Ave.parent(sheet);
    odi_econ.parent(sheet);
    odi_10w.parent(sheet);
    odi_5w.parent(sheet);
    odi_4w.parent(sheet);
    odi_balls.parent(sheet);
    odi_sr.parent(sheet);
    odi_BBI.parent(sheet);
    odi_BBM.parent(sheet);

    var T20Is = createElement('h2', "T20Is");
    var l7 = createP("------------------------");
    T20Is.parent(sheet);
    l7.parent(sheet);

    var t_sr = createElement('h2', `SR - ${t.data.bowling.T20Is.SR}`);
    var t_econ = createElement('h2', `Economy - ${t.data.bowling.T20Is.Econ}`);
    var t_balls = createElement('h2', `Balls - ${t.data.bowling.T20Is.Balls}`);
    var t_Ave = createElement('h2', `Average - ${t.data.bowling.T20Is.Ave}`);
    var t_wkts = createElement('h2', `Wickets - ${t.data.bowling.T20Is.Wkts}`);
    var t_mat = createElement('h2', `Matches - ${t.data.bowling.T20Is.Mat}`);
    var t_10w = createElement('h2', `10W - ${t.data.bowling.T20Is['10w']}`);
    var t_4w = createElement('h2', `4W - ${t.data.bowling.T20Is['4w']}`);
    var t_5w = createElement('h2', `5W - ${t.data.bowling.T20Is['5w']}`);
    var t_BBI = createElement('h2', `BBI - ${t.data.bowling.T20Is.BBI}`);
    var t_BBM = createElement('h2', `BBM - ${t.data.bowling.T20Is.BBM}`);

    t_mat.parent(sheet);
    t_wkts.parent(sheet);
    t_Ave.parent(sheet);
    t_econ.parent(sheet);
    t_10w.parent(sheet);
    t_5w.parent(sheet);
    t_4w.parent(sheet);
    t_balls.parent(sheet);
    t_sr.parent(sheet);
    t_BBI.parent(sheet);
    t_BBM.parent(sheet);


    var test = createElement('h2', "TESTS");
    var l8 = createP("------------------------");
    test.parent(sheet);
    l8.parent(sheet);

    var test_sr = createElement('h2', `SR - ${t.data.bowling.tests.SR}`);
    var test_econ = createElement('h2', `Economy - ${t.data.bowling.tests.Econ}`);
    var test_balls = createElement('h2', `Balls - ${t.data.bowling.tests.Balls}`);
    var test_Ave = createElement('h2', `Average - ${t.data.bowling.tests.Ave}`);
    var test_wkts = createElement('h2', `Wickets - ${t.data.bowling.tests.Wkts}`);
    var test_mat = createElement('h2', `Matches - ${t.data.bowling.tests.Mat}`);
    var test_10w = createElement('h2', `10W - ${t.data.bowling.tests['10w']}`);
    var test_4w = createElement('h2', `4W - ${t.data.bowling.tests['4w']}`);
    var test_5w = createElement('h2', `5W - ${t.data.bowling.tests['5w']}`);
    var test_BBI = createElement('h2', `BBI - ${t.data.bowling.tests.BBI}`);
    var test_BBM = createElement('h2', `BBM - ${t.data.bowling.tests.BBM}`);

    test_mat.parent(sheet);
    test_wkts.parent(sheet);
    test_Ave.parent(sheet);
    test_econ.parent(sheet);
    test_10w.parent(sheet);
    test_5w.parent(sheet);
    test_4w.parent(sheet);
    test_balls.parent(sheet);
    test_sr.parent(sheet);
    test_BBI.parent(sheet);
    test_BBM.parent(sheet);
}



function draw() {

}