var mat_header;
var upcoming_mat_header;

var matches_content;
var upcoming_matches_content;
var articles_content;
var t;
var data0;
var news;


function preload() {

  loadJSON("https://cricapi.com/api/matches?apikey=2PJlGa0yHGV3mMtsc2QRcx82gRn1", matches_played);
  news = loadJSON("news_cricket.json");
}

function matches_played(data1) {
  t = data1;
}

function setup() {
  noCanvas();
  mat_header = createElement('h1', "MATCHES");
  upcoming_mat_header = createElement('h1', "UPCOMING MATCHES");
  upcoming_mat_header.position(1485, 110);
  mat_header.position(150, 110);
  mat_header.style("color", "white");
  upcoming_mat_header.style("color", "white");
  ///////////////////////////////////////////////////////
  matches_content = select(".matches_box");
  upcoming_matches_content = select(".upcoming_matches");
  articles_content = select(".news_events");
  ///////////////////////////////////////////////////////
  console.log(t);
  console.log(news);
  //////////////////////////////////////////////////////
  for (let i = 0; i < t.matches.length; i++) {
    if (t.matches[i].matchStarted) {
      var f = createElement('h3', `Format - ${t.matches[i].type}`);
      var date_and_timeGMT = createElement('h6', `Date & GMT - ${t.matches[i].dateTimeGMT}`);
      var t1 = createElement('h5', `Team 1  -  ${t.matches[i]["team-1"]}`);
      var t2 = createElement('h5', `Team 2  -  ${t.matches[i]["team-2"]}`);
      var toss = createElement('h5', `Toss  -  ${t.matches[i].toss_winner_team}`);
      f.parent(matches_content); //FORMAT OF PLAY .
      date_and_timeGMT.parent(matches_content); // Date and time 
      t1.parent(matches_content); // TEAM 1
      t2.parent(matches_content); // TEAM 2
      toss.parent(matches_content); //TOSS
      var border = createP("-------------------------------------------------------------------------------");
      border.parent(matches_content);
    } else {
      var f = createElement('h3', `Format - ${t.matches[i].type}`);
      var date_and_timeGMT = createElement('h6', `Date & GMT - ${t.matches[i].dateTimeGMT}`);
      var t1 = createElement('h5', `Team 1  -  ${t.matches[i]["team-1"]}`);
      var t2 = createElement('h5', `Team 2  -  ${t.matches[i]["team-2"]}`);
      f.parent(upcoming_matches_content); //FORMAT OF PLAY .
      date_and_timeGMT.parent(upcoming_matches_content); // Date and time 
      t1.parent(upcoming_matches_content); // TEAM 1
      t2.parent(upcoming_matches_content); // TEAM 2
      var border = createP("-------------------------------------------------------------------------------");
      border.parent(upcoming_matches_content);
    }
  }
  /////////
  for (let i = news.data.length - 1 ; i != -1 ; i--) {
    var title = createElement('h2',`* - ${news.data[i].title}` );
    title.parent(articles_content);
    var pub = createElement('h5', `Published Date - ${news.data[i].publishedAt}`);
    pub.parent(articles_content);
    var img = createImg(news.data[i].urlToImage, "Loading Image");
    img.size(600, 400);
    img.parent(articles_content);
    var des = createElement('h3', `Description - ${news.data[i].description}`);
    des.parent(articles_content);
    var content = createElement('h3', news.data[i].content);
    content.parent(articles_content);
    var aut = createElement('h6', `Author - ${news.data[i].author}`);
    aut.parent(articles_content);
  }
}